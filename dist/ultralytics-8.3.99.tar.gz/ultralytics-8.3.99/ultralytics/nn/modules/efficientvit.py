import torch.nn as nn
from ultralytics.nn.modules import Conv, C2f

class EfficientViTBlock(nn.Module):
    """ 基于EfficientViT论文的轻量级Transformer块 """
    def __init__(self, dim, heads=4, expansion=4):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * expansion),
            nn.GELU(),
            nn.Linear(dim * expansion, dim)
        )
    
    def forward(self, x):
        x = x + self.attn(self.norm1(x), self.norm1(x))[0]
        x = x + self.mlp(self.norm2(x))
        return x

class EfficientViTBackbone(nn.Module):
    """ 完整的EfficientViT主干网络 """
    def __init__(self, model_name='m0', channels=(128, 256, 512)):
        super().__init__()
        # 阶段1：浅层CNN特征提取
        self.stem = nn.Sequential(
            Conv(3, 32, 3, 2),  # 下采样
            Conv(32, 64, 3, 1)
        )
        
        # 阶段2：混合CNN-ViT结构
        self.stage1 = nn.Sequential(
            C2f(64, channels[0], n=1),
            EfficientViTBlock(channels[0])
        )
        
        # 阶段3-4：深层特征
        self.stage2 = nn.Sequential(
            Conv(channels[0], channels[1], 3, 2),
            *[EfficientViTBlock(channels[1]) for _ in range(2)]
        )
        self.stage3 = nn.Sequential(
            Conv(channels[1], channels[2], 3, 2),
            *[EfficientViTBlock(channels[2]) for _ in range(4)]
        )

    def forward(self, x):
        c3 = self.stage1(self.stem(x))
        c4 = self.stage2(c3)
        c5 = self.stage3(c4)
        return [c3, c4, c5]  # 必须返回3个特征图