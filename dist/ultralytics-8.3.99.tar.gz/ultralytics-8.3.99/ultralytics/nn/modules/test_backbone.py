import torch
from ultralytics.nn.modules import EfficientViTBackbone

# 测试模块导入
print("✅ 模块导入成功")

# 测试前向传播
model = EfficientViTBackbone(channels=(128, 256, 512))
dummy_input = torch.randn(1, 3, 640, 640)
outputs = model(dummy_input)
print(f"输出特征图尺寸: {[f.shape for f in outputs]}")